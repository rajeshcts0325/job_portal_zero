@extends('layouts.app')

@section('content')
    <div class="mx-auto max-w-md p-8">
        <h1 class="mb-4 text-2xl font-bold">Register</h1>

        <p>Registration page coming soon.</p>
    </div>
@endsection