<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Validator;

Route::view('/', 'pages.home')->name('home');

Route::view('/about', 'pages.about')->name('about');

Route::view('/contact', 'pages.contact')->name('contact');

Route::view('/jobs', 'pages.jobs.index')->name('jobs.index');

Route::post('/contact', function (Request $request) {
    $validated = $request->validate([
        'name' => ['required', 'string', 'max:100'],
        'email' => ['required', 'email', 'max:255'],
        'message' => ['required', 'string', 'max:5000'],
    ]);

    // Contact submission is validated, but not yet saved or emailed.
    // Connect a mail service or database model to process it.

    return back()->with(
        'success',
        'Your message has been validated successfully.'
    );
})->name('contact.submit');


Route::view('/login', 'auth.login')->name('login');

Route::view('/register', 'auth.register')->name('register');
